## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse  = TRUE,
  comment   = "#>",
  fig.width = 7,
  fig.height = 4.5
)
set.seed(2026)

## ----load---------------------------------------------------------------------
library(mainger)

## ----dgp----------------------------------------------------------------------
n_int <- 80; n_ext <- 5000; p <- 20

X_int <- matrix(rnorm(n_int * p), n_int, p)
colnames(X_int) <- paste0("X", seq_len(p))
beta_true <- c(rep(0.5, 5), rep(0, p - 5))
Y_int <- as.numeric(X_int %*% beta_true + rnorm(n_int, 0, 1))

# External cohort with mild coefficient heterogeneity
beta_ext_true <- beta_true + rnorm(p, 0, 0.05)
X_ext <- matrix(rnorm(n_ext * p), n_ext, p)
Y_ext <- as.numeric(X_ext %*% beta_ext_true + rnorm(n_ext, 0, 1))

# External summary: coefficient and Gram matrix
theta_ext <- as.numeric(solve(crossprod(X_ext), crossprod(X_ext, Y_ext)))
Sigma_ext <- crossprod(X_ext) / n_ext

## ----partial-fit--------------------------------------------------------------
fit_partial <- mainger(X_int = X_int, Y_int = Y_int, beta_ext = theta_ext)
fit_partial

## ----partial-summary----------------------------------------------------------
summary(fit_partial)

## ----partial-coef-------------------------------------------------------------
internal_only <- as.numeric(solve(crossprod(X_int), crossprod(X_int, Y_int)))

data.frame(
  variable   = colnames(X_int),
  truth      = beta_true,
  internal   = round(internal_only, 3),
  external   = round(theta_ext, 3),
  integrated = round(fit_partial$coefficients, 3)
)[1:10, ]

## ----partial-test-------------------------------------------------------------
X_test <- matrix(rnorm(2000 * p), 2000, p)
Y_test <- as.numeric(X_test %*% beta_true + rnorm(2000, 0, 1))

mspe <- function(beta) mean((Y_test - X_test %*% beta)^2)
c(internal   = mspe(internal_only),
  external   = mspe(theta_ext),
  integrated = mspe(fit_partial$coefficients))

## ----full-fit-----------------------------------------------------------------
fit_full <- mainger(X_int = X_int, Y_int = Y_int,
                    beta_ext = theta_ext, Sigma_ext = Sigma_ext,
                    sigma2_ext = 1, n_ext = n_ext)
fit_full

## ----full-concordance---------------------------------------------------------
fit_full$concordance

## ----full-diagnose, eval = FALSE----------------------------------------------
# diagnose(fit_full)

## ----restricted-setup---------------------------------------------------------
# Simulate the restricted-access scenario from the same internal cohort
r_int     <- as.numeric(crossprod(X_int, Y_int)) / n_int
Sigma_ref <- crossprod(X_int) / n_int  # Reference panel; could be a public panel

## ----restricted-fit-----------------------------------------------------------
fit_restricted <- mainger(r_int = r_int, Sigma_ref = Sigma_ref,
                          beta_ext = theta_ext,
                          n_int = n_int, sigma2_int = 1)
fit_restricted

## ----diagnostics--------------------------------------------------------------
fit_partial$eta            # Selected eta
fit_partial$eta_bound      # Theoretical upper bound used for the grid
fit_partial$eta_grid       # Full search grid

## ----methods, eval = FALSE----------------------------------------------------
# predict(fit_partial, newdata = X_test)
# plot(fit_partial)                          # eta-vs-objective curve
# plot(fit_full,    type = "advantage")      # Full-vs-Partial concordance plot
# coef(fit_restricted)

## ----cvseed, eval = FALSE-----------------------------------------------------
# fit_partial <- mainger(X_int = X_int, Y_int = Y_int, beta_ext = theta_ext,
#                        tuning = "cv", cv_seed = 548)

